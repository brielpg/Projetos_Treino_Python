from github_brielpg.funcoes import *

# CREDITS https://github.com/brielpg

dicionario = {}

opcao = perguntar()

while opcao == "I" or opcao == "P" or opcao == "E" or opcao == "L":

    if opcao == "I":
        inserir(dicionario)

    elif opcao == "P":
        pesquisar()

    elif opcao == "E":
        excluir()

    elif opcao == "L":
        listar()

    opcao = perguntar()
