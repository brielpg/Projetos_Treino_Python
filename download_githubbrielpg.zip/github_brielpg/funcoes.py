def perguntar():
    return input("O que deseja realizar?\n"
                 "<I> - Para Inserir um usuário\n"
                 "<P> - Para Pesquisar um usuário\n"
                 "<E> - Para Excluir um usuário\n"
                 "<L> - Para Listar um usuário\n"
                 "Opçao: ").upper()


def inserir(dicionario):
    dicionario[input("Digite o login: ").upper()] = [input("Digite o nome: ").upper(),
                                                     input("Digite a última data de acesso: "),
                                                     input("Digite a última estaçao acessada: ").upper()]
    salvar(dicionario)


def salvar(dicionario):
    with open("bd.txt", "a") as arquivo:
        for chave, valor in dicionario.items():
            arquivo.write(f"\n{chave} : {str(valor)}")


def pesquisar():
    usu_pesquisar = input("Qual usuário deseja pesquisar? ").upper()
    existe = False
    with open("bd.txt", "r") as arquivo:
        for i in arquivo.readlines():
            chave, valor = i.strip().split(" : ")
            if usu_pesquisar == chave:
                print("Usuário encontrado")
                existe = True

        if not existe:
            print("Usuário não encontrado")


def excluir():
    usu_excluir = input("Qual usuário deseja excluir? ").upper()
    existe = False

    with open("bd.txt", "r+") as arquivo:
        linhas = arquivo.readlines()

        # Posicionar o cursor no início do arquivo
        arquivo.seek(0)
        arquivo.truncate()

        for i in linhas:
            chave, valor = i.strip().split(" : ")
            if usu_excluir == chave:
                existe = True
            else:
                arquivo.write(i)

    if existe:
        print("Usuário excluído com sucesso.")
    else:
        print("Usuário não encontrado.")


def listar():
    usu_listar = input("Qual usuário deseja listar? ").upper()
    existe = False
    with open("bd.txt", "r") as arquivo:
        for i in arquivo:
            chave, valor = i.strip().split(" : ")
            if usu_listar == chave:
                print(i)
                existe = True

        if not existe:
            print("Usuário não encontrado")
